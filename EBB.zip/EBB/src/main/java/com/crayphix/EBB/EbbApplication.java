package com.crayphix.EBB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbbApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbbApplication.class, args);
	}

}
